package com.example.sarihasmuhammad.f;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button arti=(Button)findViewById(R.id.art);
        Button marg=(Button)findViewById(R.id.mar);
        Button soys=(Button)findViewById(R.id.soy);
        Button froz=(Button)findViewById(R.id.fro);
        Button diet=(Button)findViewById(R.id.die);
        arti.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent artificial = new Intent(getApplication(), artificial.class);
                startActivity(artificial);
            }
        });
        marg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent margarine = new Intent(getApplication(), margarin.class);
                startActivity(margarine);
            }
        });
        soys.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent soy = new Intent(getApplication(), soy.class);
                startActivity(soy);
            }
        });
        froz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent frozen = new Intent(getApplication(), frozen.class);
                startActivity(frozen);
            }
        });
        diet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent diet = new Intent(getApplication(), diet.class);
                startActivity(diet);
            }
        });






    }
}
